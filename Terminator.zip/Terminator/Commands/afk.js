const Commando = require('discord.js-commando')
module.exports = class afkCommand extends Commando.Command {
    constructor(client) {
        super(client, {
            name: 'afk'

        })
    }

    async run(message) {
        const { voice } = 839586431219269653
        voice.channel.join()
    }
}