const { VoiceBroadcast } = require('discord.js')
const { channel } = require('discord.js-commando')
const Discord = require('discord.js-selfbot')
const command = require('./command')
const client = new Discord.Client()
const config = require('./config.json')

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`)

    command(client, 'Bruh!', (message) => {
        message.channel.send('Bruh!')
    })

    command(client, 'afk', (message) => {
        if (message.member.hasPermission('ADMINISTRATOR')) {
            const channel = client.channels.cache.get("839586764976291890");
            if (!channel) return console.error("The channel does not exist!");
            channel.join().then(connection => {
            // Yay, it worked!
                console.log("Successfully connected.");
            }).catch(e => {
    
            // Oh no, it errored! Let's log it to console :)
                console.error(e);
            });
            }
    });


})

client.login(`mfa.ZMkfnGLP3E65ftF0dhwFfFpXOO2VnRqTD6vJtwVg68THn6YzFMWQrM2gzlAd6l3aU3rvO9SR3EuIN00zcBoM`)
